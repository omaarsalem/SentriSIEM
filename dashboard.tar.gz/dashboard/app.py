# app.py
import os
import sqlite3
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from flask_socketio import SocketIO
from gevent.pywsgi import WSGIServer
from geventwebsocket.handler import WebSocketHandler
from datetime import datetime
from threading import Thread

# Initialize Flask app
app = Flask(__name__, static_folder='static', template_folder='templates')
app.secret_key = 'supersecretkey'
socketio = SocketIO(app)

# Database path
DATABASE = os.path.expanduser("~/SentriSIEM/database/sentri.db")

# User credentials
USERS = {
    "Sentri@Omar": "Sentri@Omar77"
}

# Utility functions
def query_db(query, args=(), one=False):
    """Run a SQL query on the SQLite database."""
    try:
        with sqlite3.connect(DATABASE) as conn:
            cur = conn.execute(query, args)
            rv = cur.fetchall()
            return (rv[0] if rv else None) if one else rv
    except sqlite3.OperationalError as e:
        print(f"Database error: {e}")
        return []

@app.route("/", methods=["GET", "POST"])
def login():
    """Login page with authentication."""
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        if username in USERS and USERS[username] == password:
            return redirect(url_for("dashboard"))
        else:
            flash("Invalid username or password.", "error")
    return render_template("login.html")

@app.route("/dashboard")
def dashboard():
    """Dashboard with metrics, logs, and collected data."""
    # Fetch metrics from the database
    total_logs = len(query_db("SELECT * FROM device_logs"))
    active_devices = len(set(row[2] for row in query_db("SELECT * FROM device_logs")))
    alerts = len(query_db("SELECT * FROM device_logs WHERE severity = 'Critical'"))

    # Fetch the latest logs for display
    device_logs = query_db("SELECT * FROM device_logs ORDER BY id DESC LIMIT 10")
    collected_logs = query_db("SELECT * FROM collected_logs ORDER BY id DESC LIMIT 10")

    return render_template(
        "dashboard.html",
        total_logs=total_logs,
        active_devices=active_devices,
        alerts=alerts,
        device_logs=device_logs,
        collected_logs=collected_logs,
    )

@app.route("/reports")
def reports():
    """Reports page with traffic trends, anomalies, and export options."""
    frequent_ips = query_db("SELECT source_ip, COUNT(*) as count FROM network_traffic GROUP BY source_ip ORDER BY count DESC LIMIT 5")
    protocol_usage = query_db("SELECT protocol, COUNT(*) as count FROM network_traffic GROUP BY protocol ORDER BY count DESC")
    return render_template(
        "reports.html",
        frequent_ips=frequent_ips,
        protocol_usage=protocol_usage,
    )

@app.route("/settings")
def settings():
    """Settings page for user preferences and SIEM configuration."""
    return render_template("settings.html")

@app.route("/user_management")
def user_management():
    """User management page for adding and removing users."""
    return render_template("user_management.html")

@app.route("/real_time_monitoring")
def real_time_monitoring():
    """Real-time monitoring page for live logs and device status."""
    return render_template("real_time_monitoring.html")

@app.route("/faq")
def faq():
    """FAQ page about the SIEM system."""
    return render_template("faq.html")

@app.route("/logout")
def logout():
    """Logout with a confirmation message."""
    flash("You have been logged out. Goodbye!")
    return redirect(url_for("login"))

# Background thread for simulating log monitoring
def monitor_logs():
    """Emit log updates to the dashboard in real time."""
    while True:
        socketio.emit("log_update", {"message": "New log data"})
        socketio.sleep(10)

@socketio.on("connect")
def handle_connect():
    """Handle client connections."""
    print("Client connected")

if __name__ == "__main__":
    # Start the log monitoring thread
    monitor_thread = Thread(target=monitor_logs)
    monitor_thread.daemon = True
    monitor_thread.start()

    # Configure SSL certificates
    CERT_FILE = '/home/omaar/SentriSIEM/certs/cert.pem'
    KEY_FILE = '/home/omaar/SentriSIEM/certs/key.pem'
    context = (CERT_FILE, KEY_FILE)

    # Run the server using gevent
    http_server = WSGIServer(('0.0.0.0', 5000), app, handler_class=WebSocketHandler, keyfile=KEY_FILE, certfile=CERT_FILE)
    print("Serving SentriSIEM securely on https://0.0.0.0:5000")
    http_server.serve_forever()
