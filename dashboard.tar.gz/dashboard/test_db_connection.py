import sqlite3

# Replace with your actual database path
DATABASE = "/home/omaar/SentriSIEM/database/sentri.db"

try:
    with sqlite3.connect(DATABASE) as conn:
        print("Database connected successfully")
except sqlite3.OperationalError as e:
    print(f"Error: {e}")
