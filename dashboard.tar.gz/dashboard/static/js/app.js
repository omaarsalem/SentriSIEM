document.addEventListener('DOMContentLoaded', function () {
    const socket = io.connect();
const socket = io.connect('http://127.0.0.1:5000');

socket.on('new_log', (data) => {
    const logsTableBody = document.getElementById('logs-table-body');
    const newRow = `<tr>
        <td>${data.timestamp}</td>
        <td>${data.source}</td>
        <td>${data.message}</td>
    </tr>`;
    logsTableBody.innerHTML += newRow;
});
    // Handle collected logs update
    socket.on('collected_logs_update', function (data) {
        const logsTableBody = document.getElementById('collected-logs-body');
        logsTableBody.innerHTML = ''; // Clear existing rows
        data.logs.forEach(function (log) {
            const row = `<tr>
                            <td>${log.file}</td>
                            <td><pre>${log.content.join('<br>')}</pre></td>
                         </tr>`;
            logsTableBody.innerHTML += row;
        });
    });

    // Handle disconnect
    socket.on('disconnect', function () {
        console.error('Disconnected from server');
        
    });
});
