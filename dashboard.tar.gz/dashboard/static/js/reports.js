document.addEventListener("DOMContentLoaded", () => {
    // Traffic Trends Chart
    fetch("/api/traffic_trends")
        .then(response => response.json())
        .then(data => {
            const ctx = document.getElementById("trafficTrendsChart").getContext("2d");
            const labels = data.map(item => item.capture_time);
            const values = data.map(item => item.packet_count);

            new Chart(ctx, {
                type: "line",
                data: {
                    labels: labels,
                    datasets: [{
                        label: "Packet Volume",
                        data: values,
                        borderColor: "blue",
                        fill: false
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: { display: true }
                    }
                }
            });
        });

    // Anomalies Chart
    fetch("/api/anomalies")
        .then(response => response.json())
        .then(data => {
            const ctx = document.getElementById("anomaliesChart").getContext("2d");
            const labels = data.map(item => item.capture_time);
            const values = data.map(item => item.packet_length);

            new Chart(ctx, {
                type: "scatter",
                data: {
                    labels: labels,
                    datasets: [{
                        label: "Anomalies",
                        data: values.map((v, i) => ({ x: labels[i], y: v })),
                        backgroundColor: "red"
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: { display: true }
                    },
                    scales: {
                        x: { type: "time", time: { unit: "minute" } }
                    }
                }
            });
        });
});
